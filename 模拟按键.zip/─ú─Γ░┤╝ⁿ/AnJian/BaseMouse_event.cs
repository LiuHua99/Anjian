﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace AnJian
{

    // https://wenku.baidu.com/view/bf09fee6c5da50e2534d7f5d.html  参考文章
    public class BaseMouse_event
    {   
          
        /// <summary>
        /// 获取鼠标当前坐标
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        private static extern int GetCursorPos(ref PONITAPI p);

        /// <summary>
        /// 设置鼠标坐标
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        private static extern int SetCursorPos(int x, int y);

        /// <summary>
        /// 鼠标模拟操作事件
        /// </summary>
        /// <param name="dwFlags">鼠标控制参数 （byte）enum MouseKeys</param>
        /// <param name="dx">触发坐标的X轴</param>
        /// <param name="dy">触发坐标的X轴</param>
        /// <param name="cButtons">参数0</param>
        /// <param name="dwExtraInfo">参数0</param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        public static extern int mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);      

        private static PONITAPI _ponitapis;
        /// <summary>
        /// 鼠标坐标
        /// </summary>
        public static PONITAPI Ponitapi {
            get {
                GetCursorPos(ref _ponitapis);
                return _ponitapis;
                }          
        }
       
        /// <summary>
        /// 鼠标左键单击
        /// </summary>
        public static void Mouse_LeftClick()
        {
            mouse_event((byte)MouseKeys.MOUSEEVENTF_LEFTDOWN, Ponitapi.x, Ponitapi.y, 0, 0);
            mouse_event((byte)MouseKeys.MOUSEEVENTF_LEFTUP, Ponitapi.x, Ponitapi.y, 0, 0);
        }

        /// <summary>
        /// 鼠标右键单击
        /// </summary>
        public static void Mouse_RightClick()
        {
            mouse_event((byte)MouseKeys.MOUSEEVENTF_RIGHTDOWN, Ponitapi.x, Ponitapi.y, 0, 0);
            mouse_event((byte)MouseKeys.MOUSEEVENTF_RIGHTUP, Ponitapi.x, Ponitapi.y, 0, 0);
        }

        /// <summary>
        /// 鼠标移动
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public static void Mouse_Move(int x,int y)
        {
           Bounds bounds = GetBounds();
            BaseMouse_event.mouse_event(32769, BaseMouse_event.GetCoordinate(x, bounds.Width), BaseMouse_event.GetCoordinate(y, bounds.Height), 0, 0);
        }

    
        /// <summary>
        /// 获取屏幕分辨率
        /// </summary>
        public static Bounds GetBounds()
        {
            return new Bounds { Height = Screen.PrimaryScreen.Bounds.Height, Width = Screen.PrimaryScreen.Bounds.Width };
        }


        /// <summary>
        /// 计算绝对坐标
        /// </summary>
        /// <param name="value">坐标值</param>
        /// <param name="bounds">分辨率</param>
        /// <returns></returns>
        private static int GetCoordinate(int value ,int bounds)
        {
            value += 1;
            return (int)(value * (65535f / bounds));                    
        }


    }
    /// <summary>
    /// 鼠标控制参数
    /// </summary>
    public enum MouseKeys
    {
        /// <summary>
        /// 鼠标左键按下
        /// </summary>
        MOUSEEVENTF_LEFTDOWN = 0x2,
        /// <summary>
        /// 鼠标左键弹起
        /// </summary>
        MOUSEEVENTF_LEFTUP = 0x4,
        /// <summary>
        /// 鼠标中键按下
        /// </summary>
        MOUSEEVENTF_MIDDLEDOWN = 0x20,
        /// <summary>
        /// 鼠标中键弹起
        /// </summary>
        MOUSEEVENTF_MIDDLEUP = 0x40,
        /// <summary>
        /// 鼠标移动
        /// </summary>
        MOUSEEVENTF_MOVE = 0x1,
        /// <summary>
        /// 标识是否采用绝对坐标
        /// </summary>
        MOUSEEVENTF_ABSOLUTE = 0x8000,
        /// <summary>
        /// 鼠标右键按下
        /// </summary>
        MOUSEEVENTF_RIGHTDOWN = 0x8,
        /// <summary>
        /// 鼠标右键弹起
        /// </summary>
        MOUSEEVENTF_RIGHTUP = 0x10,
    }

    public struct PONITAPI
    {
        public int x, y;
    }

    public class Bounds {
        public int Height { get; set; }
        public int Width { get; set; }
    }

}
