﻿using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows.Input;

namespace AnJian
{
  

    public class Basekeybd_event
    {                

        [DllImport("user32.dll", EntryPoint = "keybd_event", SetLastError = true)]
        private static extern void keybd_event(
            byte bVk,          // 按键的虚拟键值 可以使用枚举值System.Windows.Forms.Keys。  
            byte bScan,        // 为扫描码，一般不用设置，用0代替就行。
            uint dwFlags,      // 0: DOWN, 2: UP  
            uint dwExtraInfo   // 一般也是置0即可。
            );

        /// <summary>
        /// 模拟单个按键按下
        /// </summary>
        /// <param name="bVk">虚拟按键值 enum Keys</param>
        public static void Click_DOWN(byte bVk)
        {         
            keybd_event(bVk, 0, 0, 0);
        }
        /// <summary>
        /// 模拟单个按键弹起
        /// </summary>
        /// <param name="bVk">虚拟按键值 enum Keys</param>
        public static void Click_UP(byte bVk)
        {          
            keybd_event(bVk, 0, 2, 0);
        }

        /// <summary>
        /// 模拟单个按键按下
        /// </summary>
        /// <param name="bVk">虚拟按键值 enum Keys</param>
        public static void Click_DOWN(Keys bVk)
        {
            Click_DOWN((byte)bVk);
        }
        /// <summary>
        /// 模拟单个按键弹起
        /// </summary>
        /// <param name="bVk">虚拟按键值 enum Keys</param>
        public static void Click_UP(Keys bVk)
        {          
            Click_UP((byte)bVk);
        }



        /// <summary>
        /// 模拟按键点击
        /// </summary>
        /// <param name="bVk">(byte)Keys</param>
        public static void Click(byte bVk)
        {
            Click_DOWN(bVk);
            Click_UP(bVk);
        }

        /// <summary>
        /// 模拟单个按键点击
        /// </summary>
        /// <param name="bVk">虚拟按键值 enum Keys</param>
        public static void Click(Keys bVk)
        {
            Click_DOWN(bVk);
            Click_UP(bVk);
        }

        /// <summary>
        /// 模拟多个按键按下
        /// </summary>
        /// <param name="keys">按顺序输入多个按键</param>
        public static void ClickS_Down(Keys[] keys)
        {
            foreach (Keys key in keys)
            {
                Click_DOWN((byte)key);
            }
        }

        public static void ClickS_Down(char[] keys)
        {
            foreach (char key in keys)
            {
                Click_DOWN((byte)key);
            }
        }

        /// <summary>
        /// 模拟多个按键弹起
        /// </summary>
        /// <param name="keys">按顺序输入多个按键</param>
        public static void ClickS_Up(Keys[] keys)
        {
            foreach (Keys key in keys)
            {
                Click_UP((byte)key);
            }
        }

        public static void ClickS_Up(char[] keys)
        {
            foreach (char key in keys)
            {
                Click_UP((byte)key);
            }
        }

        /// <summary>
        /// 模拟多个按键点击
        /// </summary>
        /// <param name="keys">按顺序输入多个按键</param>
        public static void ClickS(Keys[] keys)
        {
            ClickS_Down(keys);
            ClickS_Up(keys);
        }

        public static void ClickS(char[] keys)
        {
            ClickS_Down(keys);
            ClickS_Up(keys);
        }

    }

    /// <summary>
    /// 虚拟按键值
    /// </summary>
    public enum Keys
    {
        /// <summary>
        /// 鼠标左键
        /// </summary>
        VK_LBUTTON = 1,
        /// <summary>
        /// 鼠标右键
        /// </summary>
        VK_RBUTTON = 2,
        /// <summary>
        /// Ctrl-Break键
        /// </summary>
        VK_CANCEL = 3,
        /// <summary>
        /// 鼠标中键
        /// </summary>
        VK_MBUTTON = 4,
        /// <summary>
        ///Backspace键
        /// </summary>
        VK_BACK = 8,
        /// <summary>
        /// Tab键
        /// </summary>
        VK_TAB = 9,
        /// <summary>
        /// Clear键
        /// </summary>
        VK_CLEAR = 12,
        /// <summary>
        /// Enter键
        /// </summary>
        VK_RETURN = 13,
        /// <summary>
        /// Shift键
        /// </summary>
        VK_SHIFT = 16,
        /// <summary>
        /// Ctrl键
        /// </summary>
        VK_CONTROL = 17,
        /// <summary>
        /// Alt键
        /// </summary>
        VK_MENU = 18,
        /// <summary>
        /// Pause键
        /// </summary>
        VK_PAUSE = 19,
        /// <summary>
        /// Caps Lock键
        /// </summary>
        VK_CAPITAL = 20,
        /// <summary>
        /// Esc键
        /// </summary>
        VK_ESCAPE = 27,
        /// <summary>
        /// Space键
        /// </summary>
        VK_SPACE = 32,
        /// <summary>
        /// Page Up键
        /// </summary>
        VK_PRIOR = 33,
        /// <summary>
        /// //Page Down键
        /// </summary>
        VK_NEXT = 34,
        /// <summary>
        /// End键
        /// </summary>
        VK_END = 35,
        /// <summary>
        /// Home键
        /// </summary>
        VK_HOME = 36,
        /// <summary>
        /// ←键
        /// </summary>
        VK_LEFT = 37,
        /// <summary>
        ///↑键
        /// </summary>
        VK_UP = 38,
        /// <summary>
        /// →键
        /// </summary>
        VK_RIGHT = 39,
        /// <summary>
        /// ↓键
        /// </summary>
        VK_DOWN = 40,
        /// <summary>
        /// Select键
        /// </summary>
        VK_SELECT = 41,
        /// <summary>
        /// Print键
        /// </summary>
        VK_PRINT = 42,
        /// <summary>
        /// Execute键
        /// </summary>
        VK_EXECUTE = 43,
        /// <summary>
        /// Print Screen键
        /// </summary>
        VK_SNAPSHOT = 44,
        /// <summary>
        /// Ins键
        /// </summary>
        VK_INSERT = 45,
        /// <summary>
        /// Del键
        /// </summary>
        VK_DELETE = 46,
        /// <summary>
        /// Help键
        /// </summary>
        VK_HELP = 47,   
        VK_0 = 48,  //0键
        VK_1 = 49,  //1键
        VK_2 = 50,  //2键
        VK_3 = 51,  //3键
        VK_4 = 52,  //4键
        VK_5 = 53,  //5键
        VK_6 = 54,  //6键
        VK_7 = 55,  //7键
        VK_8 = 56,  //8键
        VK_9 = 57,  //9键
        VK_A = 65,  //A键
        VK_B = 66,  //B键
        VK_C = 67,  //C键
        VK_D = 68,  //D键
        VK_E = 69,  //E键
        VK_F = 70,  //F键
        VK_G = 71,  //G键
        VK_H = 72,  //H键
        VK_I = 73,  //I键
        VK_J = 74,  //J键
        VK_K = 75,  //K键
        VK_L = 76,  //L键
        VK_M = 77,  //M键
        VK_N = 78,  //N键
        VK_O = 79,  //O键
        VK_P = 80,  //P键
        VK_Q = 81,  //Q键
        VK_R = 82,  //R键
        VK_S = 83,  //S键
        VK_T = 84,  //T键
        VK_U = 85,  //U键
        VK_V = 86,  //V键
        VK_W = 87,  //W键
        VK_X = 88,  //X键
        VK_Y = 89,  //Y键
        VK_Z = 90,  //Z键
        /// <summary>
        /// 左Windows键
        /// </summary>
        VK_LWIN = 91,
        /// <summary>
        /// 右Windows键
        /// </summary>
        VK_RWIN = 92,   
        /// <summary>
        /// 应用程序键
        /// </summary>
        VK_APPS = 93,
        /// <summary>
        /// 休眠键
        /// </summary>
        VK_SLEEP = 95,
        /// <summary>
        ///小数字键盘0键
        /// </summary>
        VK_NUMPAD0 = 96,
        /// <summary>
        /// 小数字键盘1键
        /// </summary>
        VK_NUMPAD1 = 97,
        /// <summary>
        /// 小数字键盘2键
        /// </summary>
        VK_NUMPAD2 = 98,
        /// <summary>
        /// 小数字键盘3键
        /// </summary>
        VK_NUMPAD3 = 99,
        /// <summary>
        /// 小数字键盘4键
        /// </summary>
        VK_NUMPAD4 = 100,
        /// <summary>
        /// 小数字键盘5键
        /// </summary>
        VK_NUMPAD5 = 101,
        /// <summary>
        /// 小数字键盘6键
        /// </summary>
        VK_NUMPAD6 = 102,
        /// <summary>
        /// 小数字键盘7键
        /// </summary>
        VK_NUMPAD7 = 103,
        /// <summary>
        /// 小数字键9键
        /// </summary>
        VK_NUMPAD9 = 105,
        /// <summary>
        /// 乘号键
        /// </summary>
        VK_MULTIPLY = 106,
        /// <summary>
        /// 加号键
        /// </summary>
        VK_ADD = 107,
        /// <summary>
        /// 分割键
        /// </summary>
        VK_SEPARATOR = 108,
        /// <summary>
        /// 小数点键
        /// </summary>
        VK_DECIMAL = 110,
        /// <summary>
        /// 除号键
        /// </summary>
        VK_DIVIDE = 111,    
        VK_F1 = 12,     //F1键
        VK_F2 = 113,    //F2键
        VK_F3 = 114,    //F3键
        VK_F4 = 115,    //F4键
        VK_F5 = 116,    //F5键
        VK_F6 = 117,    //F6键
        VK_F7 = 118,    //F7键
        VK_F8 = 119,    //F8键
        VK_F9 = 120,    //F9键
        VK_F10 = 121,   //F10键
        VK_F11 = 122,   //F11键
        VK_F12 = 123,   //F12键
        VK_F13 = 124,   //F13键
        VK_F14 = 125,   //F14键
        VK_F15 = 126,   //F15键
        VK_F16 = 127,   //F16键
        VK_F17 = 128,   //F17键
        VK_F18 = 129,   //F18键
        VK_F19 = 130,   //F19键
        VK_F20 = 131,   //F20键
        VK_F21 = 132,   //F21键
        VK_F22 = 133,   //F22键
        VK_F23 = 134,   //F23键
        VK_F24 = 135,   //F24键
        /// <summary>
        /// Num Lock键
        /// </summary>
        VK_NUMLOCK = 144,
        /// <summary>
        /// Scroll Lock键
        /// </summary>
        VK_SCROLL = 45,
        /// <summary>
        /// 左Shift键
        /// </summary>
        VK_LSHIFT = 160,
        /// <summary>
        /// 右Shift键
        /// </summary>
        VK_RSHIFT = 161,
        /// <summary>
        /// 左Ctrl键
        /// </summary>
        VK_LCONTROL = 162,
        /// <summary>
        /// 右Ctrl键
        /// </summary>
        VK_RCONTROL = 163,
        /// <summary>
        /// 左Alt键
        /// </summary>
        VK_LMENU = 164,
        /// <summary>
        /// 右Alt键
        /// </summary>
        VK_RMENU = 165,
        /// <summary>
        ///  ;   :
        /// </summary>
        VK_分号  =  186,
        /// <summary>
        ///  =   +
        /// </summary>
        VK_等于 = 187,
        /// <summary>
        ///  ,  <
        /// </summary>
        VK_逗号=188,
        /// <summary>
        ///  -  _
        /// </summary>
        VK_减号 = 189,
        /// <summary>
        ///  .  >
        /// </summary>
        VK_句号=190,
        /// <summary>
        ///  /  ?
        /// </summary>
        VK_斜杠 = 191,
        /// <summary>
        ///  `   ~
        /// </summary>
        VK_点_Esc下面 = 192,
        /// <summary>
        ///  [  {
        /// </summary>
        VK_中括号_左 = 219,
        /// <summary>
        ///  \   |
        /// </summary>
        VK_反斜杠 = 220,
        /// <summary>
        ///  ]   }
        /// </summary>
        VK_中括号_右 = 221,
        /// <summary>
        ///  '  "
        /// </summary>
        VK_引号 = 222                                             
    }

}
